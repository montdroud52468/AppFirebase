package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class Visualizar extends AppCompatActivity {

    DatabaseReference fire;
    Button prue,prue2;
    TextView text;
    String dato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar);

        text = findViewById(R.id.texto);
        prue=findViewById(R.id.Prue);
        prue2=findViewById(R.id.Prue2);

        fire = FirebaseDatabase.getInstance().getReference();

        ObtenerDatos();
    }

    private void ObtenerDatos() {
        fire.child("Usuario").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (final DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    fire.child("Usuario").child(snapshot.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            usuario user = snapshot.getValue(usuario.class);
                            String nombre = user.getNombre();
                            String apellido = user.getApellido();
                            String pres = user.getPrestamo();
                            String rest = user.getRestante();
                            Log.e("Datos: ", "" + snapshot.getValue());
                            dato = dato+snapshot.getValue();
                            text.setText(snapshot.getValue()+" ");
                            prue.setText(nombre+" "+apellido);
                            prue2.setText(nombre+" "+apellido);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }


}
