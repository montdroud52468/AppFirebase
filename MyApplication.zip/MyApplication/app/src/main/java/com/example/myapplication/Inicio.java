package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Inicio extends AppCompatActivity {

    Button agre,ver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        agre=findViewById(R.id.agregar);
        ver=findViewById(R.id.ver);

        agre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ag;
                ag = new Intent(Inicio.this,agregar.class);
                startActivity(ag);

            }
        });
        ver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ag;
                ag = new Intent(Inicio.this,Visualizar.class);
                startActivity(ag);

            }
        });

    }
}