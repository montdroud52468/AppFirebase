package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class agregar extends AppCompatActivity {

    DatabaseReference fire;
    Button agregar;
    EditText nom,ape,res,pre;
    String dato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);

        agregar=findViewById(R.id.suburd);

        nom=findViewById(R.id.anombre);
        ape=findViewById(R.id.aapellido);
        res=findViewById(R.id.aresta);
        pre=findViewById(R.id.aprestamo);

        fire = FirebaseDatabase.getInstance().getReference();

        ObtenerDatos();
    }

    private void ObtenerDatos() {
        fire.child("Usuario").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(final DataSnapshot snapshot: dataSnapshot.getChildren()){
                    fire.child("Usuario").child(snapshot.getKey()).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            usuario user=snapshot.getValue(usuario.class);
                            String nombre=user.getNombre();
                            Log.e("Datos: ",""+snapshot.getValue());
                            dato=dato+snapshot.getValue();
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre=nom.getText().toString();
                String apellido=ape.getText().toString();
                String rest=res.getText().toString();
                String pres=pre.getText().toString();
                cargardatos(nombre, apellido, rest, pres);
            }
        });
    }

    private void cargardatos(String nombre, String apellido, String rest, String pres) {
        Map<String,Object> datosUsuario=new HashMap<>();
        datosUsuario.put("nombre",nombre);
        datosUsuario.put("apellido",apellido);
        datosUsuario.put("restante",rest);
        datosUsuario.put("prestamo",pres);
        fire.child("Usuario").push().setValue(datosUsuario);
    }
}